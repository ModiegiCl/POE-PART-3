/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

class Message { // <-- removed 'public'
    private String messageID;
    private String messageHash;
    private String recipient;
    private String messageText;
    private String flag;
    private String sender;
    private static int messageCount = 0;

    public Message(String recipient, String messageText, String flag, String sender) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.flag = flag;
        this.sender = sender;
        messageCount++;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    private String createMessageHash() {
        String idPrefix = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].toUpperCase().replaceAll("[^A-Z]", "");
        String lastWord = words[words.length - 1].toUpperCase().replaceAll("[^A-Z]", "");
        return idPrefix + ":" + messageCount + ":" + firstWord + lastWord;
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getFlag() { return flag; }
    public String getSender() { return sender; }
    public void setMessageID(String messageID) { 
        this.messageID = messageID; 
        this.messageHash = createMessageHash();
    }
    public static void resetCount() { messageCount = 0; }
}

class MessageManager { // <-- removed 'public'
    private ArrayList<Message> sentMessages = new ArrayList<>();
    private ArrayList<Message> disregardedMessages = new ArrayList<>();
    private ArrayList<Message> storedMessages = new ArrayList<>();

    public void addMessage(Message msg) {
        switch (msg.getFlag()) {
            case "Sent": sentMessages.add(msg); break;
            case "Disregard": disregardedMessages.add(msg); break;
            case "Stored": storedMessages.add(msg); break;
        }
    }

    public String getLongestStoredMessage() {
        if (storedMessages.isEmpty()) return "";
        Message longest = storedMessages.get(0);
        for (Message msg : storedMessages) {
            if (msg.getMessageText().length() > longest.getMessageText().length()) {
                longest = msg;
            }
        }
        return longest.getMessageText();
    }

    public String searchByMessageID(String id) {
        for (Message msg : getAllMessages()) {
            if (msg.getMessageID().equals(id)) {
                return "Recipient: " + msg.getRecipient() + ", Message: " + msg.getMessageText();
            }
        }
        return "Message ID not found";
    }

    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();
        for (Message msg : getAllMessages()) {
            if (msg.getRecipient().equals(recipient)) {
                results.add(msg.getMessageText());
            }
        }
        return results;
    }

    public String deleteByHash(String hash) {
        for (Message msg : storedMessages) {
            if (msg.getMessageHash().equals(hash)) {
                storedMessages.remove(msg);
                return "Message: \"" + msg.getMessageText() + "\" successfully deleted.";
            }
        }
        return "Message hash not found";
    }

    public List<String> displaySentReport() {
        List<String> report = new ArrayList<>();
        for (Message msg : sentMessages) {
            report.add("Hash: " + msg.getMessageHash() + " | Recipient: " + msg.getRecipient() + " | Message: " + msg.getMessageText());
        }
        return report;
    }

    private ArrayList<Message> getAllMessages() {
        ArrayList<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(disregardedMessages);
        all.addAll(storedMessages);
        return all;
    }

    public ArrayList<Message> getSentMessages() { return sentMessages; }
    public ArrayList<Message> getStoredMessages() { return storedMessages; }
}

// Only this class stays public because file is Main.java
public class Main {
    public static void main(String[] args) {
        Message.resetCount();
        MessageManager mm = new MessageManager();
        
        // Test data from your spec
        Message msg1 = new Message("+27834557896", "Did you get the cake?", "Sent", "0831234567");
        Message msg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", "0831234567");
        Message msg3 = new Message("+27834484567", "Yohoooo, I am at your gate.", "Disregard", "0831234567");
        Message msg4 = new Message("0838884567", "It is dinner time!", "Sent", "0831234567");
        Message msg5 = new Message("+27838884567", "Ok, I am leaving without you.", "Stored", "0831234567");
        msg4.setMessageID("1234567890");
        
        mm.addMessage(msg1);
        mm.addMessage(msg2);
        mm.addMessage(msg3);
        mm.addMessage(msg4);
        mm.addMessage(msg5);

        // Test 1: Sent Messages array populated correctly
        System.out.println("Test 1 - Sent Messages:");
        for (Message m : mm.getSentMessages()) {
            System.out.println(m.getMessageText());
        }
        
        // Test 2: Longest Message
        System.out.println("\nTest 2 - Longest: " + mm.getLongestStoredMessage());
        
        // Test 3: Search by messageID
        System.out.println("\nTest 3 - Search ID: " + mm.searchByMessageID("1234567890"));
        
        // Test 4: Search by recipient
        System.out.println("\nTest 4 - Search Recipient: " + mm.searchByRecipient("+27838884567"));
        
        // Test 5: Delete by hash
        System.out.println("\nTest 5 - Delete: " + mm.deleteByHash(msg2.getMessageHash()));
        
        // Test 6: Display Report
        System.out.println("\nTest 6 - Report:");
        for (String s : mm.displaySentReport()) {
            System.out.println(s);
        }
    }
}


	
		